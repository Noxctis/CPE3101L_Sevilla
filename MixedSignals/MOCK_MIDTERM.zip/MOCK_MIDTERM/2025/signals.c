//Do not edit this function.
//This is the function for a unit step
double u(t)
{

  if (t >= 0)
    return 1.0;
  else
    return 0.0;
}


//Edit this function as needed but keep the function prototype
double x(double t)
{
  return u(t-1);
}


//Edit this function as needed but keep the function prototype
double y(double t)
{
  return t*u(t+3.14);
}

//Edit this function as needed but keep the function prototype
double z(double t)
{
  return t*u(t+3.14);
}

//Edit this function as needed but keep the function prototype
double r(double t)
{
  return t >= 0.0 ? 1.0 : -1.0;
}








